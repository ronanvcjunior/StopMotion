void initGrid(int, int);
void drawGrid();
void drawBotamon();
